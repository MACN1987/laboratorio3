

#Nesta pasta deve se colocar os arquivos brutos, e neles não se deve mexer, pois o mesmo será utilizados para realizar um roolback caso necessite.